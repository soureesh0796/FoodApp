import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  menu: Menu[];
  inputNumber: Array<Number>;

  constructor(private router: Router, private menuService: MenuService, private authService: AuthenticationService) {
    this.inputNumber=new Array<Number>();
   }

  ngOnInit() {
    this.menuService.listMenu()
    .subscribe(data => {
      this.menu=data;
    });
  };

  addToCart(menu){
    console.log(this.inputNumber[menu.id]);
    menu.quantity=this.inputNumber[menu.id];
    this.menuService.addToCart(menu)
    .subscribe(
      data => {
        console.log(data);
        this.ngOnInit();
      },
      error => console.log(error));
  }

  logout(){
    this.authService.deleteToken();
    this.router.navigate(['/login']);
  }
}
