package com.food.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.model.Cart;
import com.food.model.Item;
import com.food.repository.CartRepository;
import com.food.repository.ItemRepository;

@Service("deliveryService")
public class DeliveryServiceImpl implements DeliveryService {

	@Autowired
	ItemRepository itemRep;

	@Autowired
	CartRepository cartRep;

	@Override
	public List<Item> listMenu() {
		return itemRep.findAll();
	}

	@Override
	@Transactional
	public void addToCart(Item item, String userId) {
		boolean exists=false;
		Item orderedItem = itemRep.findOne(item.getId());
		List<Cart> cartList=cartRep.findAll();
		
		for(Cart c:cartList) {
			if(c.getuserId().equals(userId) && c.getFoodItem().equals(item.getItemName())) {
				exists=true;
			}
		}
		
		Cart cart = new Cart();
		String itemName=item.getItemName();
		
		if(exists) {
			Cart newCart=cartRep.findByIdAndFood(userId, itemName);
			newCart.setFoodQuantity(newCart.getFoodQuantity()+item.getQuantity());
			cartRep.save(newCart);
		}
		else {
			cart.setFoodItem(orderedItem.getItemName());
			cart.setFoodQuantity(item.getQuantity());
			cart.setCost(item.getQuantity()*orderedItem.getPrice());
			cart.setuserId(userId);
			orderedItem.setQuantity(orderedItem.getQuantity()-item.getQuantity());
			cartRep.save(cart);
		}
	}

	@Override
	@Transactional
	public List<Cart> listCart(String userId) {
		return cartRep.findByUserId(userId);
	}

	@Override
	@Transactional
	public int getTotalCost(String userId) {

		if(cartRep.getTotalCost(userId)==null) {
			return 0;
		}
		return cartRep.getTotalCost(userId);
	}

	@Override
	public void proceedToPay(String userId) {
		List<Cart> cartList=cartRep.findByUserId(userId);
		
		for(Cart cart: cartList) {
			cartRep.delete(cart);
		}
	}
}
