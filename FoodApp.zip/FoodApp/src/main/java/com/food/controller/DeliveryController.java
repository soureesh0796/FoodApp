package com.food.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.food.model.Cart;
import com.food.model.Item;
import com.food.service.DeliveryService;

import io.jsonwebtoken.Jwts;

@RestController
@CrossOrigin(origins = "http://localhost:4211")
public class DeliveryController {

	@Autowired(required = true)
	private DeliveryService deliveryService;

	@GetMapping("/listMenu")
	@CrossOrigin(origins = "http://localhost:4211")
	public List<Item> lsitMenu() {
		System.out.println("inside");
		return deliveryService.listMenu();
	}
	
	@PostMapping("addToCart")
	@CrossOrigin(origins = "http://localhost:4211")
	public ResponseEntity<String> addToCart(HttpServletRequest request, @RequestBody Item item) {
		System.out.println(item.getId()+" "+item.getQuantity());
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
        System.out.println(userId);
		deliveryService.addToCart(item,userId);
		String response="Added";
		return new ResponseEntity<String>(response,HttpStatus.OK);
	}
	
	@GetMapping("/listCart")
	@CrossOrigin(origins = "http://localhost:4211")
	public List<Cart> listCart(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		System.out.println(userId);
		List<Cart> cartList=deliveryService.listCart(userId);
		return cartList;
	}
	
	@GetMapping("/totalCost")
	@CrossOrigin(origins = "http://localhost:4211")
	public String getTotalCost(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		System.out.println(userId);
		return Integer.toString(deliveryService.getTotalCost(userId));
	}
	
	@PostMapping("/proceedToPay")
	@CrossOrigin(origins = "http://localhost:4211")
	public ResponseEntity<String> proceedToPay(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
        System.out.println(userId);
		deliveryService.proceedToPay(userId);
		String response="Processed";
		return new ResponseEntity<String>(response,HttpStatus.OK);
	} 

}
