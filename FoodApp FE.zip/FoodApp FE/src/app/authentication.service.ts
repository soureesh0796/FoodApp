import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { User } from './user';

import * as jwt_decode from 'jwt-decode';

export const TOKEN_NAME: string = "jwt_token";

@Injectable()
export class AuthenticationService {
  token: string;
  decoded: any;

  constructor(private http: HttpClient) { }

  loginUser(user): Observable<any> {
    console.log(user);
    return this.http.post('http://localhost:8089/loginUser', user);
  }

  setToken(token:string) {
    return localStorage.setItem(TOKEN_NAME, token);
  }

  getToken() {
    return localStorage.getItem(TOKEN_NAME);
  }

  deleteToken() {
    return localStorage.removeItem(TOKEN_NAME);
  }

  getTokenExpirationDate(token: string) {
    this.decoded = jwt_decode(token);
    if(this.decoded.exp === undefined) {
      return null;
    }
    const date = new Date(0);
    date.setUTCSeconds(this.decoded.exp);
    return date;
  }

  isTokenExpired(token?: string): boolean {
    if(!token) {
      token = this.getToken();
    }
    if(!token) {
      return true;
    }
    const date = this.getTokenExpirationDate(token);
    if(date === undefined || date === null) {
      return false;
    }
    return !(date.valueOf() > new Date().valueOf());
  }
}