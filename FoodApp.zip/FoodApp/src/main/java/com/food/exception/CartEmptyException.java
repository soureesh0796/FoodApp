package com.food.exception;

public class CartEmptyException {

}
