package com.user.service;

import java.util.Map;

import com.user.model.User;

public interface SecurityTokenGenerator {
	Map<String, String> generateToken(User user);
}
