import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../user';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { UserService } from '../user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isValidFormSubmitted = false;
  user = new User();
  message: string;
  form: NgForm;
  notValid: boolean = false;


  constructor(private router: Router, private authService: AuthenticationService, private userService: UserService) { }

  ngOnInit() {
  }

  loginUser() {
    console.log("Login user", this.user);
    this.authService.loginUser(this.user).subscribe(data => {
      if (data) {
        console.log(data);
        console.log("Login successful");
        this.authService.setToken(data['token']);
        this.router.navigate(['/menu']);
      }
    }, error => {
      if (error = 'User Not Valid') {
        console.log("error");
        this.notValid = true;
        this.message = "Invalid Username/Password...";
        this.form.resetForm();
        this.router.navigate(['/login']);
        setTimeout(function () {
          this.notValid = false;
        }.bind(this), 4000);
      }
    })
  }

  onFormSubmit(form) {
    this.form=form;
    if (form.invalid) {
      return;
    }
    this.user = form.value;
    this.loginUser();
    this.user = new User();
  }
}
