import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '../cart';
import { CartService } from '../cart.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart[];
  totalCost: String;
  buttonShow:boolean;
  message: String;

  constructor(private router: Router, private cartService: CartService) { }

  ngOnInit() {
    this.cartService.listCart()
      .subscribe(data => {
        this.cart = data;
      });

    this.cartService.getTotalCost()
      .subscribe(data => {
        this.totalCost = data;
        console.log( this.totalCost);
         if(this.totalCost=='0')
         {
             this.buttonShow=false;
             this.message='Your cart is empty! Please click on menu to order food...';
             console.log( this.totalCost);
         }
         else
         {
           this.buttonShow=true;
          
         }
      });
  };

  proceedToPay() {
    this.cartService.proceedToPay()
      .subscribe(
      data => {
        console.log(data);
        this.ngOnInit();
      },
      error => console.log(error));
      this.router.navigate(['/success']);
  }

}
