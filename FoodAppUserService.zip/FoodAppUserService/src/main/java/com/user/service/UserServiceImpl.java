package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.model.User;
import com.user.repository.UserRepository;
import com.user.exception.UserAlreadyExistsException;
import com.user.exception.UserNotFoundException;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRep;

	@Override
	public boolean createUser(User user) throws UserAlreadyExistsException {
		List<User> userList=userRep.findAll();
		for(User u:userList) {
			if(user.getEmail().equals(u.getEmail())||user.getUsername().equals(u.getUsername())) {
				//System.out.println("fail");
				throw new UserAlreadyExistsException("User already exists! Please try again with a different email-id or username");
			}
		}
		//System.out.println("registered");
		userRep.save(user);
		return true;
	}

	@Override
	public User findByUsernameAndPassword(String email, String password) throws UserNotFoundException{
		User user=userRep.findByUsernameAndPassword(email, password);
		
		if(user == null) {
			throw new UserNotFoundException("Invalid username/password...");
		}	
		return user;
	}
}
