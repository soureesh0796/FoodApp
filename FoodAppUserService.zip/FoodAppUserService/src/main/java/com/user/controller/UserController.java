package com.user.controller;

import java.util.Map;

import com.user.service.SecurityTokenGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.user.exception.UserAlreadyExistsException;
import com.user.exception.UserNotFoundException;
import com.user.model.User;
import com.user.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4211")
public class UserController {
	
	@Autowired(required=true)
	private UserService userService;
	
	@Autowired
	private SecurityTokenGenerator tokenGenerator;
	
	@PostMapping("/createUser")
	@CrossOrigin(origins = "http://localhost:4211")
	public ResponseEntity<?> createUser(@RequestBody User user) {
		try {
			boolean response=userService.createUser(user);
			return new ResponseEntity<Boolean>(response, HttpStatus.CREATED);
		}
		catch (UserAlreadyExistsException e){
			//System.out.println(e.getMessage());
			return new ResponseEntity<String>("User Already Exists", HttpStatus.CONFLICT);
		}
	}
	
	@PostMapping("/loginUser")
	@CrossOrigin(origins = "http://localhost:4211")
	public ResponseEntity<?> loginUser(@RequestBody User loggedUser) {
		try {
			System.out.println(loggedUser.getUsername()+" "+loggedUser.getPassword());
			User user=userService.findByUsernameAndPassword(loggedUser.getUsername(),loggedUser.getPassword());	
			Map<String, String> map = tokenGenerator.generateToken(user);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
		catch(UserNotFoundException e) {
			return new ResponseEntity<String>("User Not Valid", HttpStatus.UNAUTHORIZED);
		}
	}
}
