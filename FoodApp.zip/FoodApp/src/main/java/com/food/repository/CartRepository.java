package com.food.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.food.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	@Query("select sum(cost) from Cart where userId=:userId")
	public Integer getTotalCost(@Param("userId") String userId);
	
	@Query("from Cart where userId=:userId")
	List<Cart> findByUserId(@Param("userId") String userId);
	
	@Query("from Cart where userId=:userId and foodItem=:foodItem")
	public Cart findByIdAndFood(@Param("userId") String uId, @Param("foodItem") String fName);

}
