package com.user.service;

import com.user.exception.UserAlreadyExistsException;
import com.user.exception.UserNotFoundException;
import com.user.model.User;

public interface UserService {

	boolean createUser(User user) throws UserAlreadyExistsException;

	User findByUsernameAndPassword(String email, String password) throws UserNotFoundException;

}
